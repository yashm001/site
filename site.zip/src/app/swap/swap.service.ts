import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { env } from 'process';
@Injectable({
  providedIn: 'root'
})
export class SwapService {
  private bscBalance = environment.apiurl + 'balanceOf_BSC?token=SHIH&userAddress=';
  private bscToeth = environment.apiurl + 'getBSCAmountAfterFee?token=SHIH&amount=';
  private ethBalance = environment.apiurl + 'balanceOf_ETH?token=SHIH&userAddress=';
  private ethtobsc = environment.apiurl + 'getETHAmountAfterFee?token=SHIH&amount=';


  private swapBsc = environment.apiurl + 'getTransactionResponse?txHash=';
  private swapeth = environment.apiurl + 'getTransactionResponseETH?txHash=';
  
  private ETHbridgeFee = environment.apiurl + 'getETHBridgeFees?token=SHIH&toChain=BSC';
  private BSCbridgeFee = environment.apiurl + 'getBSCBridgeFees?token=SHIH&toChain=ETH';
  private getContratAddress = environment.apiurl + 'getContractAddress?token=SHIH';

  private getFantomVaultBalance = environment.apiurl + 'ETHVaultBalance?token=SHIH';
  private getBscVaultBalance = environment.apiurl + 'BSCVaultBalance?token=SHIH';

  constructor(private http:HttpClient) {
    
   }

   getBSCBalanace(bscWalletAddress:any){
     return this.http.get(this.bscBalance+bscWalletAddress);
   }

   bscToEthConvert(data:any){
     return this.http.get(this.bscToeth+data)
   }

   getETHBalanace(ethWalletAddress:any){
    return this.http.get(this.ethBalance+ethWalletAddress);
  }

  ethToBscConvert(data:any){
    return this.http.get(this.ethtobsc+data)
  }

  bscSwap(trnxHash:any , timeStamp:any , swapAmount:any){
    return this.http.get(environment.apiurl + "getBSCTransactionResponse?txHash=" + trnxHash + "&fromTimestamp=" + timeStamp + "&swapAmount=" + swapAmount + "&token=SHIH&toChain=ETH");
  }

  ethSwap(trnxHash:any , timeStamp:any , swapAmount:any){
    return this.http.get(environment.apiurl + "getETHTransactionResponse?txHash=" + trnxHash + "&fromTimestamp=" + timeStamp + "&swapAmount=" + swapAmount + "&token=SHIH&toChain=BSC");
  }

  checkBSCAllowance(amount:any , userAddress:any ){
    return this.http.get(environment.apiurl + "checkBSCAllowance?amount=" + amount + "&userAddress=" + userAddress + "&token=SHIH");
  }

  checkETHAllowance(amount:any , userAddress:any){
    return this.http.get(environment.apiurl + "checkETHAllowance?amount=" + amount + "&userAddress=" + userAddress +  "&token=SHIH");
  }



  getETHbridgeFee(){
    return this.http.get(this.ETHbridgeFee);
  }

  getBSCbridgeFee(){
    return this.http.get(this.BSCbridgeFee)
  }

  getContractAddresses(){
    return this.http.get(this.getContratAddress)
  }

  getBSC_vaultBalance(){
    return this.http.get(this.getBscVaultBalance);
  }

  getFantom_vaultBalance(){
    return this.http.get(this.getFantomVaultBalance)
  }

}
