import { DigitsOnlyDirective } from './digits-only.directive';

describe('DigitsOnlyDirective', () => {
  it('should create an instance', () => {
    const directive = new DigitsOnlyDirective();
    expect(directive).toBeTruthy();
  });
});
