export const environment = {
  production: false,
  // apiurl : 'https://swapapi.catoshi.cat/api/catoshi/',      //miannet
  // apiurl: 'http://18.216.159.218:4000/api/catoshi/',       //testnet
  apiurl: 'http://3.141.29.170:4000/api/catoshi/',       //testnet
   
  getAllTransaction:'https://api-ropsten.etherscan.io/'
  // apiurl : 'http://199.192.31.214:4000/api/catoshi/',   
  // apiurl : 'http://localhost:4000/api/catoshi/'


  };
