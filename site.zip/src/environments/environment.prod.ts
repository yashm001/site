export const environment = {
  production: true,
  apiurl : 'https://swapapi.catoshi.cat/api/catoshi/',         
  getAllTransaction:'https://api-ropsten.etherscan.io/'
  // apiurl : 'http://199.192.31.214:4000/api/catoshi/',   
  // apiurl : 'http://localhost:4000/api/catoshi/'
};
